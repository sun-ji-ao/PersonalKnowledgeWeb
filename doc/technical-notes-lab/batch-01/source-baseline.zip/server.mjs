import http from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { openStore } from './lib/store.mjs';
import { importMarkdown, renderMarkdown, escapeHtml } from './lib/content.mjs';
import { shell, indexView, articleView, loginView, editorView } from './lib/views.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 4310);
const dataDir = path.resolve(process.env.DATA_DIR || path.join(root, 'data'));
await mkdir(dataDir, { recursive: true });
const passwordPath = path.join(dataDir, 'admin-password.txt');
if (!existsSync(passwordPath)) await writeFile(passwordPath, randomBytes(18).toString('base64url'), { mode: 0o600 });
const adminPassword = process.env.ADMIN_PASSWORD || (await readFile(passwordPath, 'utf8')).trim();
if (adminPassword.length < 12) throw new Error('ADMIN_PASSWORD 至少需要 12 个字符');
const store = openStore(path.join(dataDir, 'notes.sqlite'));
const sessions = new Map(), attempts = new Map();
const origins = new Set([`http://127.0.0.1:${port}`, `http://localhost:${port}`]);
if (!store.list().length && process.env.SEED_DEMO !== '0') {
  const sample = importMarkdown(await readFile(path.join(root, 'example.md'), 'utf8'), 'example.md');
  const note = store.create(sample); store.publish(note.id, note.version);
}
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function session(req) {
  const id = /(?:^|;\s*)notes_session=([^;]+)/.exec(req.headers.cookie || '')?.[1];
  const value = sessions.get(id);
  if (!value || value < Date.now()) { sessions.delete(id); return false; }
  return true;
}
async function body(req) {
  if (!req.headers['content-type']?.startsWith('application/json')) throw Object.assign(new Error('请使用 JSON 请求'), { status: 415 });
  const chunks = []; let length = 0;
  for await (const chunk of req) { length += chunk.length; if (length > 2 * 1024 * 1024) throw Object.assign(new Error('笔记超过 2 MB 限制'), { status: 413 }); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('请求内容不是有效 JSON'), { status: 400 }); }
}
function validate(input) {
  if (typeof input.title !== 'string' || !input.title.trim() || input.title.length > 200 || typeof input.markdown !== 'string' || typeof input.description !== 'string' || input.description.length > 500 || !Array.isArray(input.tags) || input.tags.length > 20 || input.tags.some(t => typeof t !== 'string' || t.length > 80)) throw Object.assign(new Error('标题、摘要或标签格式不正确'), { status: 400 });
  return { ...input, title: input.title.trim() };
}
async function asset(res, filename, base) {
  const resolved = path.resolve(base, filename);
  if (!resolved.startsWith(path.resolve(base) + path.sep)) return send(res, 404, { error: '未找到文件' });
  const types = { '.css': 'text/css', '.js': 'text/javascript', '.mjs': 'text/javascript', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
  if (!types[path.extname(resolved)]) return send(res, 404, { error: '未找到文件' });
  try { send(res, 200, await readFile(resolved), types[path.extname(resolved)]); } catch { send(res, 404, { error: '未找到文件' }); }
}
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: http: data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
  try {
    if (!origins.has(`http://${req.headers.host}`)) return send(res, 403, { error: '不允许的访问地址' });
    const url = new URL(req.url, `http://${req.headers.host}`), route = url.pathname;
    if (!['GET', 'HEAD'].includes(req.method) && !origins.has(req.headers.origin)) return send(res, 403, { error: '请求来源校验失败' });
    if (route.startsWith('/vendor/katex/')) return asset(res, route.slice('/vendor/katex/'.length), path.join(root, 'node_modules/katex/dist'));
    if (route.startsWith('/vendor/mermaid/')) return asset(res, route.slice('/vendor/mermaid/'.length), path.join(root, 'node_modules/mermaid/dist'));
    if (['/styles.css', '/reader.js', '/editor.js', '/favicon.svg'].includes(route)) return asset(res, route.slice(1), path.join(root, 'public'));
    if (route === '/api/login' && req.method === 'POST') {
      const now = Date.now(), ip = req.socket.remoteAddress, previous = attempts.get(ip);
      const entry = previous && previous.until > now ? previous : { count: 0, until: now + 15 * 60_000 };
      if (entry.count >= 10) return send(res, 429, { error: '尝试次数过多，请稍后再试' });
      const input = await body(req), provided = Buffer.from(String(input.password || '')), expected = Buffer.from(adminPassword);
      if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) { entry.count++; attempts.set(ip, entry); return send(res, 401, { error: '密码不正确' }); }
      attempts.delete(ip);
      const id = randomBytes(32).toString('hex'); sessions.set(id, now + 24 * 3600_000);
      res.setHeader('Set-Cookie', `notes_session=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`);
      return send(res, 200, { ok: true });
    }
    if (route === '/' && req.method === 'GET') return send(res, 200, indexView(store.publicList()), 'text/html; charset=utf-8');
    if (route === '/write' && req.method === 'GET') return send(res, 200, session(req) ? editorView() : loginView(), 'text/html; charset=utf-8');
    const publicArticle = route.match(/^\/notes\/([a-f0-9-]+)$/);
    const publicExport = route.match(/^\/api\/public\/notes\/([a-f0-9-]+)\/export$/);
    if ((publicArticle || publicExport) && req.method === 'GET') {
      const note = store.get((publicArticle || publicExport)[1]);
      if (!note?.published_at) return send(res, 404, shell('未找到笔记', '<main class="login-main"><h1>这篇笔记尚未公开。</h1><a href="/">返回全部笔记</a></main>'), 'text/html; charset=utf-8');
      if (publicExport) { res.setHeader('Content-Disposition', `attachment; filename="note-${note.id}.md"`); return send(res, 200, `# ${note.published_title}\n\n${note.published_markdown}`, 'text/markdown; charset=utf-8'); }
      return send(res, 200, articleView(note, await renderMarkdown(note.published_markdown)), 'text/html; charset=utf-8');
    }
    if (route.startsWith('/api/')) {
      if (!session(req)) return send(res, 401, { error: '请先登录写作台' });
      if (route === '/api/logout' && req.method === 'POST') { const id = /notes_session=([^;]+)/.exec(req.headers.cookie || '')?.[1]; sessions.delete(id); res.setHeader('Set-Cookie', 'notes_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'); return send(res, 200, { ok: true }); }
      if (route === '/api/notes' && req.method === 'GET') return send(res, 200, store.list());
      if (route === '/api/notes' && req.method === 'POST') return send(res, 201, store.create(validate(await body(req))));
      if (route === '/api/import' && req.method === 'POST') { const input = await body(req); if (typeof input.markdown !== 'string' || !/\.(md|markdown)$/i.test(input.filename || '')) return send(res, 400, { error: '请选择 Markdown 文件' }); return send(res, 201, store.create(validate(importMarkdown(input.markdown, input.filename)))); }
      if (route === '/api/preview' && req.method === 'POST') { const input = await body(req); if (typeof input.markdown !== 'string') return send(res, 400, { error: '缺少 Markdown 内容' }); return send(res, 200, await renderMarkdown(input.markdown)); }
      const match = route.match(/^\/api\/notes\/([a-f0-9-]+)(?:\/(publish|unpublish|export))?$/);
      if (match) {
        const [, id, action] = match; const note = store.get(id);
        if (!note) return send(res, 404, { error: '笔记不存在' });
        if (action === 'export' && req.method === 'GET') { res.setHeader('Content-Disposition', `attachment; filename="note-${id}.md"`); const metadata = { ...note.source_metadata, title: note.title, description: note.description, tags: note.tags }; return send(res, 200, `---\n${JSON.stringify(metadata, null, 2)}\n---\n\n${note.markdown}`, 'text/markdown; charset=utf-8'); }
        if (!action && req.method === 'GET') return send(res, 200, note);
        if (!action && req.method === 'PUT') { const input = validate(await body(req)); const saved = store.save(id, input); return saved ? send(res, 200, saved) : send(res, 409, { error: '另一页面已修改此笔记。请先导出当前内容，再刷新重新打开。' }); }
        if (action === 'publish' && req.method === 'POST') { const input = await body(req); if (!note.title.trim() || !note.markdown.trim()) return send(res, 400, { error: '请填写标题和正文后再发布' }); const published = store.publish(id, input.version); return published ? send(res, 200, published) : send(res, 409, { error: '内容已变化，请保存后重新发布' }); }
        if (action === 'unpublish' && req.method === 'POST') return send(res, 200, store.unpublish(id));
      }
    }
    send(res, 404, { error: '未找到页面' });
  } catch (error) { send(res, error.status || 500, { error: error.status ? error.message : '处理失败，请检查输入内容或稍后重试' }); if (!error.status) console.error(error.message); }
});
server.listen(port, '127.0.0.1', () => console.log(`知页已启动：http://127.0.0.1:${port}\n站主密码位置：${passwordPath}`));
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => { store.close(); process.exit(0); }));
